"""
Package for InClassDjangoLine6.
"""
